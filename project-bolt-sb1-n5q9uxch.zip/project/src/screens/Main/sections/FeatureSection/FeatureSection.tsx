import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const FeatureSection = (): JSX.Element => {
  // Stats data for the Solana integration cards
  const statsCards = [
    {
      value: "1,090",
      label: "Validator Nodes",
      description:
        "The Solana network is validated by thousands of nodes that operate independently of each other, ensuring your data remains secure and censorship resistant.",
      size: "small",
    },
    {
      value: "0%",
      label: "Net Carbon Impact",
      description:
        "Solana's proof of stake network and other innovations minimize its impact on the environment. Each Solana transaction uses about the same energy as a few Google searches.",
      size: "large",
    },
    {
      value: "3,753",
      label: "Transactions per Second",
      description:
        "Solana has block times of 400 milliseconds — and as hardware gets faster, so will the network.",
      size: "small",
    },
  ];

  // Partner logos data
  const partners = [
    {
      alt: "Logohorizontal black",
      src: "/logohorizontal-black-1.png",
      width: "599.02px",
      height: "148px",
    },
    {
      alt: "Lavarage logo",
      src: "/lavarage-logo-horizontal1-1.png",
      width: "500.83px",
      height: "91px",
    },
    {
      alt: "Lavarage logo",
      src: "/lavarage-logo-horizontal1-2.png",
      width: "350px",
      height: "105px",
    },
  ];

  // Feature cards data
  const featureCards = [
    {
      title: "ANALYTICS ≠ INTELLIGENCE",
      description:
        "COGNIHASH IS BUILDING THE FIRST AGENTIC AI OPERATING SYSTEM FOR THE MODULAR, REAL-TIME, ONCHAIN WORLD.",
    },
    {
      title: "VERSATILE & ADAPTABLE",
      description:
        "COGNIHASH ARCHITECTURE SEAMLESSLY INTEGRATES WITH ANY EXISTING BLOCKCHAIN PROTOCOL—FROM DEFI TO OTHER ON-CHAIN ACTIVITIES AND BEYOND.",
    },
    {
      title: "USER FRIENDLY",
      description:
        "EACH AGENT OWNS A SINGLE RESPONSIBILITY. THE SYSTEM COORDINATES. CONTROL IS COMPOSABLE.",
    },
  ];

  return (
    <section className="flex flex-col items-center justify-center gap-32 py-32 w-full">
      <div className="flex flex-col items-center gap-9 max-w-[1499px] w-full">
        <img
          className="w-auto h-[96.5px] object-cover"
          alt="Size color color"
          src="/size-96--color-color-black-2x-2.png"
        />

        <div className="flex flex-col items-center gap-2 max-w-[1096px] w-full">
          <h2 className="[font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-gray-900 text-4xl text-center tracking-[0] leading-[45px]">
            Cognihash Including Solana&nbsp;&nbsp;Integration to delivers high
            performance &amp; scalability.
          </h2>
        </div>

        <div className="flex items-center justify-between gap-[90px] w-full">
          {statsCards.map((card, index) => (
            <Card
              key={`stat-card-${index}`}
              className={`border border-solid border-black rounded-[15px] ${
                card.size === "large" ? "w-[583px]" : "w-[368px]"
              }`}
            >
              <CardContent
                className={`flex flex-col items-center justify-center p-6 ${
                  card.size === "large" ? "py-10" : "py-6"
                }`}
              >
                <div
                  className={`[font-family:'ABC_Diatype_Semi-Mono-Bold',Helvetica] font-bold text-[#043e5d] text-center ${
                    card.size === "large" ? "text-8xl" : "text-5xl"
                  }`}
                >
                  {card.value}
                  <br />
                  <span
                    className={
                      card.size === "large" ? "text-[56px]" : "text-2xl"
                    }
                  >
                    {card.label}
                  </span>
                </div>
                <div className="[font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-[#043e5d] text-[15px] text-center mt-2">
                  {card.description}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="flex flex-col items-center gap-8 w-full">
        <div className="flex items-center justify-center w-full max-w-[1117px] py-10">
          <h2 className="[font-family:'ABC_Diatype-Bold',Helvetica] font-bold text-[#043e5d] text-8xl text-center">
            Our Partner &amp; Ecosystem
          </h2>
        </div>

        <div className="flex items-center justify-center gap-[66px] w-full max-w-[1762.67px]">
          {partners.map((partner, index) => (
            <img
              key={`partner-${index}`}
              className="object-cover"
              alt={partner.alt}
              src={partner.src}
              style={{ width: partner.width, height: partner.height }}
            />
          ))}
        </div>
      </div>

      <div className="flex flex-col items-center gap-10 w-full">
        <div className="flex flex-col items-center gap-10 w-full">
          <div className="flex flex-col items-center gap-4 w-full">
            <div className="flex flex-col items-center justify-center w-full">
              <h2 className="[font-family:'ABC_Diatype-Medium',Helvetica] font-medium text-[#043e5d] text-[56px] tracking-[-0.56px]">
                Why choose CogniHash?
              </h2>
            </div>

            <div className="flex flex-col items-center justify-center">
              <p className="[font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-[#043e5d] text-[22px] text-center">
                CogniHash is building the first AI-native OS for blockchain
                thinking.
                <br /> Where AI agents don&apos;t just observe the chain—they
                understand, trace, and act on it in real time.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-10">
            {featureCards.map((feature, index) => (
              <Card
                key={`feature-card-${index}`}
                className="w-[435px] h-[400px] bg-[#8effd0] rounded-[35px] overflow-hidden border-none"
              >
                <CardContent className="flex flex-col w-[349px] items-start pt-10 pl-[43px] pr-0 pb-0 h-full">
                  <h3 className="[font-family:'ABC_Diatype-Bold',Helvetica] font-bold text-[#043e5d] text-[40px]">
                    {feature.title.includes("&") ? (
                      <>
                        {feature.title.split("&")[0]}
                        <br />
                        &amp; {feature.title.split("&")[1]}
                      </>
                    ) : feature.title.includes("USER") ? (
                      <>
                        USER
                        <br />
                        FRIENDLY
                      </>
                    ) : (
                      feature.title
                    )}
                  </h3>
                  <div className="w-[278px] [font-family:'ABC_Diatype-Light',Helvetica] font-light text-[#043e5d] text-base">
                    {feature.title.includes("VERSATILE") && <br />}
                    {feature.description}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="flex items-start gap-2">
          <div className="flex items-center justify-center p-[13px] rounded-[22.5px] border border-solid border-[#043e5d]">
            <div className="w-[19px] h-[19px] bg-[url(/component-1-1.svg)] bg-[100%_100%]" />
          </div>
          <div className="flex items-center justify-center p-[13px] rounded-[22.5px] border border-solid border-[#043e5d]">
            <div className="w-[19px] h-[19px] bg-[url(/component-1.svg)] bg-[100%_100%]" />
          </div>
        </div>
      </div>
    </section>
  );
};
