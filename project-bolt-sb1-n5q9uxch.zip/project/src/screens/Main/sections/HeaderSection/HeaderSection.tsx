import React from "react";
import { Button } from "../../../../components/ui/button";

export const HeaderSection = (): JSX.Element => {
  // Navigation menu items
  const menuItems = [
    { label: "Product" },
    { label: "About Us" },
    { label: "Roadmap" },
    { label: "Pricing" },
  ];

  return (
    <header className="relative w-full bg-white overflow-hidden">
      <div className="container mx-auto px-4 relative">
        {/* Logo and Brand */}
        <div className="flex items-center pt-12">
          <img
            className="w-14 h-14 object-cover"
            alt="Logo"
            src="/logo-black-transbg-3x-1.png"
          />
          <div className="font-semibold text-black text-[32px] leading-5 whitespace-nowrap font-['Plus_Jakarta_Sans',Helvetica]">
            CogniHash
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="flex justify-center mt-[-20px]">
          <div className="inline-flex items-center gap-[29px] px-[52px] py-[26px] rounded-[40px] bg-[linear-gradient(90deg,rgba(255,255,255,0.3)_0%,rgba(255,255,255,0.15)_100%)]">
            {menuItems.map((item, index) => (
              <div
                key={index}
                className="inline-flex items-center justify-center gap-2.5 p-2 cursor-pointer"
              >
                <div className="font-medium text-black text-lg font-['ABC_Diatype-Medium',Helvetica]">
                  {item.label}
                </div>
              </div>
            ))}
          </div>
        </nav>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-16">
          <div className="flex flex-col items-start gap-9 py-16">
            {/* Headline */}
            <div className="flex flex-col items-start">
              <div className="font-normal text-black text-8xl tracking-[-0.75px] leading-[112px] font-['ABC_Diatype-Regular',Helvetica]">
                Let Blockchain
              </div>
              <div className="flex items-center">
                <span className="text-[#14f195] font-normal text-8xl tracking-[-0.75px] leading-[112px] font-['ABC_Diatype-Regular',Helvetica]">
                  Data Think
                </span>
                <span className="font-normal text-black text-8xl tracking-[-0.75px] leading-[112px] font-['ABC_Diatype-Regular',Helvetica] ml-4">
                  for You
                </span>
              </div>
            </div>

            {/* Subheading */}
            <div className="max-w-[800px]">
              <p className="font-normal text-black text-2xl font-['ABC_Diatype-Regular',Helvetica]">
                CogniHash AI is the AI-native operating system powering
                real-time, precision-grade intelligence for blockchain
                ecosystems.
              </p>
            </div>

            {/* CTA Button */}
            <Button className="px-[41px] py-[17px] bg-[#14f195] rounded-[64px] border border-solid border-black hover:bg-[#0dd584]">
              <span className="font-extrabold text-black text-2xl text-center leading-8 font-['Plus_Jakarta_Sans',Helvetica]">
                Start Now
              </span>
            </Button>
          </div>

          {/* Hero Image */}
          <div className="relative h-full">
            <img
              className="w-full h-auto object-cover"
              alt="Header image"
              src="/header-image.png"
            />
          </div>
        </div>
      </div>
    </header>
  );
};
