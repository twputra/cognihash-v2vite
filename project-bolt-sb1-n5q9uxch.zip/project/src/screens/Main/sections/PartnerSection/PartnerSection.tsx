import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const PartnerSection = (): JSX.Element => {
  // Define partner icons data for mapping
  const partnerIcons = [
    {
      alt: "Account circle",
      src: "/account-circle.png",
      pulse1: "/pulse-1-6.svg",
      pulse2: "/pulse-2-4.svg",
    },
    {
      alt: "Comment",
      src: "/comment.png",
      pulse1: "/pulse-1-7.svg",
      pulse2: "/pulse-2-6.svg",
    },
    {
      alt: "Robot",
      src: "/robot-2-8.png",
      pulse1: "/pulse-1-4.svg",
      pulse2: "/pulse-2-1.svg",
    },
    {
      alt: "Mask group",
      src: "/mask-group-1.png",
      pulse1: "/pulse-1-2.svg",
      pulse2: "/pulse-2.svg",
      secondIcon: {
        alt: "Database",
        src: "/database-1.png",
        pulse1: "/pulse-1.svg",
        pulse2: "/pulse-2-2.svg",
      },
    },
  ];

  return (
    <section className="relative w-full py-16 overflow-hidden">
      {/* Background gradient effects */}
      <div className="relative w-full h-full">
        <div className="absolute inset-0 bg-[#f7f7f7] overflow-hidden">
          <div className="relative w-full h-full">
            {/* Gradient blobs */}
            <div className="w-[1173px] h-[1173px] absolute blur-[114.92px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(153,69,255,1)_0%,rgba(127,109,235,1)_20%,rgba(99,153,215,1)_45%,rgba(72,195,178,1)_65%,rgba(20,241,149,1)_86%)]" />
            <div className="w-[1792px] h-[1792px] absolute blur-[114.92px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(153,69,255,1)_0%,rgba(127,109,235,1)_20%,rgba(99,153,215,1)_45%,rgba(72,195,178,1)_65%,rgba(20,241,149,1)_86%)]" />
            <div className="w-[1792px] h-[1792px] absolute blur-[114.92px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(153,69,255,1)_0%,rgba(127,109,235,1)_20%,rgba(99,153,215,1)_45%,rgba(72,195,178,1)_65%,rgba(20,241,149,1)_86%)]" />
          </div>
        </div>

        {/* Noise overlay */}
        <div className="absolute inset-0 [background:url(..//noise-animation.png)_50%_50%_/_cover]" />

        {/* Main content card */}
        <Card className="relative mx-auto max-w-5xl mt-24 bg-[#ffffff42] rounded-[66px] border-[0.5px] border-solid border-[#000000d4]">
          <CardContent className="p-0">
            <div className="flex flex-col w-full">
              {/* Vision section */}
              <div className="flex flex-col items-center px-14 py-[26px]">
                <div className="flex flex-col items-center gap-6 w-full">
                  <h2 className="text-8xl font-medium text-center bg-[linear-gradient(180deg,rgba(4,62,93,1)_0%)] [-webkit-background-clip:text] bg-clip-text text-transparent [font-family:'ABC_Diatype-Medium',Helvetica]">
                    Vision
                  </h2>
                  <div className="max-w-[700px]">
                    <p className="text-2xl font-medium text-center text-[#043e5d] [font-family:'ABC_Diatype-Medium',Helvetica]">
                      To become the AI backbone of global blockchain
                      infrastructure—empowering institutions, protocols, and
                      users with transparent, autonomous, and real-time
                      decision-making capabilities.
                    </p>
                  </div>
                </div>
              </div>

              {/* Missions section */}
              <div className="flex flex-col items-center px-14 py-[26px]">
                <div className="flex flex-col items-center gap-6 w-full">
                  <h2 className="text-8xl font-medium text-center bg-[linear-gradient(180deg,rgba(4,62,93,1)_0%)] [-webkit-background-clip:text] bg-clip-text text-transparent [font-family:'ABC_Diatype-Medium',Helvetica]">
                    Missions
                  </h2>
                  <div className="max-w-[700px]">
                    <p className="text-2xl font-medium text-center text-[#043e5d] [font-family:'ABC_Diatype-Medium',Helvetica]">
                      We democratize blockchain intelligence through autonomous
                      agents and interoperable AI systems. By eliminating
                      friction in data workflows, CogniHash enables fast,
                      secure, and informed action—without writing a single line
                      of code.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Partner icons row */}
        <div className="relative flex justify-center gap-6 mt-16">
          {partnerIcons.map((icon, index) => (
            <div
              key={`partner-${index}`}
              className="relative w-[200px] h-[200px]"
            >
              {/* Glow effect */}
              <div className="w-[440px] h-[152px] absolute top-5 left-6 rounded-[220px/76px] blur-[55.67px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(98,77,227,1)_0%,rgba(193,31,245,1)_23%,rgba(250,3,255,1)_41%,rgba(250,3,255,1)_51%,rgba(178,7,255,1)_65%,rgba(21,16,255,1)_86%)] opacity-10" />

              {/* Pulse effects */}
              <img
                className="absolute w-[200px] h-[200px] top-0 left-0"
                alt="Pulse"
                src={icon.pulse1}
              />
              <img
                className="absolute w-[200px] h-[200px] top-0 left-0"
                alt="Pulse"
                src={icon.pulse2}
              />

              {/* Icon container */}
              <div className="absolute top-[46px] left-[46px] flex items-center justify-around">
                <div className="inline-flex items-start gap-2 p-[22px] rounded-3xl overflow-hidden border-none shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                  <img className="w-16 h-16" alt={icon.alt} src={icon.src} />
                </div>

                {/* Second icon for the last item */}
                {icon.secondIcon && (
                  <div className="ml-24 flex items-center justify-center p-4 w-[108px] h-[108px] rounded-3xl overflow-hidden border-none shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                    <img
                      className="w-16 h-16"
                      alt={icon.secondIcon.alt}
                      src={icon.secondIcon.src}
                    />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
