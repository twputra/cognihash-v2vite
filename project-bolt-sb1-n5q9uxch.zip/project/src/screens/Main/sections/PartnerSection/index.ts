export { PartnerSection } from "./PartnerSection";
