import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

// Data for the content sections
const contentSections = [
  {
    title: "Zero Dev \n0verhead",
    description:
      "CogniHash operates on the principle that blockchain intelligence should be autonomous, scalable, and accessible, transforming raw data into actionable insights.\nIt's not another tool—it's your \nAI-native intelligence layer.",
    ctaText: "Just ask. Get results",
    imageSrc: "..//680ba0cdfb351a3c4c2d2b42-human-in-the-loop-gif-v4-gif.png",
  },
  {
    title: "HMAS",
    description:
      "Higher-level agents supervise and coordinate lower-level agents to achieve complex tasks aligned with broader objectives. Each agent has specialized roles, and the system ensures scalability, modularity, and adaptability.\n\nA layered structure with supervisor agents coordinating midlevel coordinators and low-level executors, utilizing Solanas smart contracts for task delegation and execution.",
    ctaText: "Read the Doc's Now",
  },
  {
    title: "Model Context\nProtocol (MCP)",
    description:
      "MCP is an open protocol that standardizes how applications provide context to LLMs. Think of MCP like a USB-C port for AI applications. Just as USB-C provides a standardized way to connect your device.",
    ctaText: "Read the Doc's Now",
  },
];

// Robot data for HMAS visualization
const robotImages = [
  { src: "/robot-2.png", alt: "Robot" },
  { src: "/robot-2-1.png", alt: "Robot" },
  { src: "/robot-2-2.png", alt: "Robot" },
  { src: "/robot-2-3.png", alt: "Robot" },
  { src: "/robot-2-4.png", alt: "Robot" },
  { src: "/robot-2-5.png", alt: "Robot" },
  { src: "/robot-2-6.png", alt: "Robot" },
];

// MCP visualization data
const mcpImages = [
  { src: "/robot-2-7.png", alt: "Robot" },
  { src: "/mask-group.png", alt: "Mask group" },
  { src: "/database.png", alt: "Database" },
];

export const MainContentSection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full max-w-[1596px] mx-auto gap-[50px] py-16">
      {/* Zero Dev 0verhead Section */}
      <div className="flex flex-col md:flex-row items-center gap-8 md:gap-[286px] w-full">
        <div className="flex flex-col w-full md:w-[513px] items-start gap-[87px]">
          <div className="flex flex-col items-start w-full">
            <h2 className="font-bold text-[#043e5d] text-6xl md:text-8xl tracking-[-0.75px] leading-[97px] [font-family:'ABC_Diatype_Semi-Mono-Bold',Helvetica]">
              Zero Dev <br />
              0verhead
            </h2>
          </div>

          <div className="flex flex-col items-start gap-7 w-full">
            <p className="text-wwwlangchaincomte-papa-green text-lg md:text-[22px] leading-[35.2px] [font-family:'ABC_Diatype-Regular',Helvetica]">
              <br />
              CogniHash operates on the principle that blockchain intelligence
              should be autonomous, scalable, and accessible, transforming raw
              data into actionable insights.
              <br />
              It&apos;s not another tool—it&apos;s your <br />
              AI-native intelligence layer.
            </p>

            <div className="w-full max-w-[436px] border-b border-[#1d3d3c] pb-2 relative">
              <div className="flex justify-between items-center">
                <span className="font-normal text-wwwlangchaincomte-papa-green text-lg md:text-[22px] leading-[35.2px] [font-family:'ABC_Diatype-Regular',Helvetica]">
                  Just ask. Get results
                </span>
                <img
                  className="w-[15px] h-3"
                  alt="Component"
                  src="/component-2.svg"
                />
              </div>
            </div>
          </div>
        </div>

        <Card className="w-full md:w-[797px] h-[706px] rounded-[35px] border-black overflow-hidden">
          <CardContent
            className="p-0 h-full w-full bg-cover bg-center"
            style={{
              backgroundImage:
                "url(..//680ba0cdfb351a3c4c2d2b42-human-in-the-loop-gif-v4-gif.png)",
            }}
          ></CardContent>
        </Card>
      </div>

      {/* HMAS Section */}
      <div className="flex flex-col md:flex-row items-center gap-8 md:gap-[286px] w-full">
        <div className="flex flex-col w-full md:w-[513px] items-start gap-[87px]">
          <div className="flex flex-col items-start w-full">
            <h2 className="font-bold text-[#043e5d] text-6xl md:text-8xl tracking-[-0.75px] leading-[97px] whitespace-nowrap [font-family:'ABC_Diatype_Semi-Mono-Bold',Helvetica]">
              HMAS
            </h2>
          </div>

          <div className="flex flex-col gap-[117px] items-start w-full">
            <p className="text-wwwlangchaincomte-papa-green text-lg md:text-[22px] leading-[35.2px] [font-family:'ABC_Diatype-Regular',Helvetica]">
              Higher-level agents supervise and coordinate lower-level agents to
              achieve complex tasks aligned with broader objectives. Each agent
              has specialized roles, and the system ensures scalability,
              modularity, and adaptability.
              <br />
              <br />A layered structure with supervisor agents coordinating
              midlevel coordinators and low-level executors, utilizing Solanas
              smart contracts for task delegation and execution.
            </p>

            <div className="w-full max-w-[436px] border-b border-[#1d3d3c] pb-2 relative">
              <div className="flex justify-between items-center">
                <span className="font-normal text-wwwlangchaincomte-papa-green text-lg md:text-[22px] leading-[35.2px] [font-family:'ABC_Diatype-Regular',Helvetica]">
                  Read the Doc&apos;s Now
                </span>
                <img
                  className="w-[15px] h-3"
                  alt="Component"
                  src="/component-2.svg"
                />
              </div>
            </div>
          </div>
        </div>

        <Card className="w-full md:w-[799px] rounded-[35px] border-black">
          <CardContent className="p-2.5 flex items-center justify-center">
            <div className="relative w-full max-w-[685px] h-[686px]">
              {/* Background snake graphics */}
              <div className="relative w-full h-full">
                <div className="left-[15px] rotate-[121.72deg] absolute w-[480px] h-[164px] top-[165px]">
                  <div className="relative w-[605px] h-[593px] top-[-215px] left-[-63px]">
                    <img
                      className="w-[371px] h-[482px] top-11 left-[117px] rotate-[-121.72deg] absolute"
                      alt="Snake fastest"
                      src="/snake-fastest-1.svg"
                    />
                    <img
                      className="w-[371px] h-[482px] top-11 left-[117px] rotate-[-121.72deg] absolute"
                      alt="Snake fast"
                      src="/snake-fast-1.svg"
                    />
                    <img
                      className="w-[371px] h-[482px] top-[68px] left-[117px] rotate-[-121.72deg] absolute"
                      alt="Snake slow"
                      src="/snake-slow-1.svg"
                    />
                    <img
                      className="w-[371px] h-[482px] top-14 left-[117px] rotate-[-121.72deg] absolute"
                      alt="Snake slowest"
                      src="/snake-slowest-1.svg"
                    />
                    <div className="w-[440px] top-[200px] left-[74px] rounded-[220px/76px] absolute h-[152px] blur-[55.67px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(98,77,227,1)_0%,rgba(193,31,245,1)_23%,rgba(250,3,255,1)_41%,rgba(250,3,255,1)_51%,rgba(178,7,255,1)_65%,rgba(21,16,255,1)_86%)] opacity-10" />
                  </div>
                </div>

                <div className="left-[188px] rotate-[58.28deg] absolute w-[480px] h-[164px] top-[165px]">
                  <div className="relative w-[605px] h-[593px] top-[-215px] left-[-63px]">
                    <img
                      className="w-[371px] h-[482px] top-[68px] left-[117px] rotate-[-58.28deg] absolute"
                      alt="Snake fastest"
                      src="/snake-fastest.svg"
                    />
                    <img
                      className="w-[371px] h-[482px] top-[68px] left-[117px] rotate-[-58.28deg] absolute"
                      alt="Snake fast"
                      src="/snake-fast.svg"
                    />
                    <img
                      className="w-[371px] h-[482px] top-11 left-[117px] rotate-[-58.28deg] absolute"
                      alt="Snake slow"
                      src="/snake-slow.svg"
                    />
                    <img
                      className="w-[371px] h-[482px] top-14 left-[117px] rotate-[-58.28deg] absolute"
                      alt="Snake slowest"
                      src="/snake-slowest.svg"
                    />
                    <div className="w-[440px] top-[200px] left-[74px] rounded-[220px/76px] absolute h-[152px] blur-[55.67px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(98,77,227,1)_0%,rgba(193,31,245,1)_23%,rgba(250,3,255,1)_41%,rgba(250,3,255,1)_51%,rgba(178,7,255,1)_65%,rgba(21,16,255,1)_86%)] opacity-10" />
                  </div>
                </div>
              </div>

              {/* Robot hierarchy visualization */}
              <div className="flex flex-col w-[606px] h-[589px] items-center gap-[91px] absolute top-[97px] left-10">
                {/* Top level robot */}
                <div className="flex w-[108px] h-[108px] items-start gap-2 p-[22px] relative rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                  <img
                    className="w-16 h-16"
                    alt={robotImages[0].alt}
                    src={robotImages[0].src}
                  />
                </div>

                {/* Middle and bottom level robots */}
                <div className="flex items-center gap-[58px] w-full">
                  {/* Left group */}
                  <div className="flex flex-col w-[274px] items-center gap-[91px]">
                    <div className="flex w-[108px] h-[108px] items-start gap-2 p-[22px] relative rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                      <img
                        className="w-16 h-16"
                        alt={robotImages[1].alt}
                        src={robotImages[1].src}
                      />
                    </div>

                    <div className="relative w-[274px] h-[108px]">
                      <div className="flex w-[108px] h-[108px] absolute top-0 left-0 items-start gap-2 p-[22px] rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                        <img
                          className="w-16 h-16"
                          alt={robotImages[2].alt}
                          src={robotImages[2].src}
                        />
                      </div>

                      <div className="flex w-[108px] h-[108px] absolute top-0 left-[166px] items-start gap-2 p-[22px] rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                        <img
                          className="w-16 h-16"
                          alt={robotImages[3].alt}
                          src={robotImages[3].src}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Right group */}
                  <div className="flex flex-col w-[274px] items-center gap-[91px]">
                    <div className="flex w-[108px] h-[108px] items-start gap-2 p-[22px] relative rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                      <img
                        className="w-16 h-16"
                        alt={robotImages[4].alt}
                        src={robotImages[4].src}
                      />
                    </div>

                    <div className="relative w-[274px] h-[108px]">
                      <div className="flex w-[108px] h-[108px] absolute top-0 left-0 items-start gap-2 p-[22px] rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                        <img
                          className="w-16 h-16"
                          alt={robotImages[5].alt}
                          src={robotImages[5].src}
                        />
                      </div>

                      <div className="flex w-[108px] h-[108px] absolute top-0 left-[166px] items-start gap-2 p-[22px] rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                        <img
                          className="w-16 h-16"
                          alt={robotImages[6].alt}
                          src={robotImages[6].src}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Model Context Protocol Section */}
      <div className="flex flex-col md:flex-row items-center gap-8 md:gap-[362px] w-full">
        <div className="flex flex-col w-full md:w-[513px] items-start gap-[87px]">
          <div className="flex flex-col items-start w-full">
            <h2 className="font-bold text-[#043e5d] text-6xl md:text-8xl tracking-[-0.75px] leading-[97px] [font-family:'ABC_Diatype_Semi-Mono-Bold',Helvetica]">
              Model Context
              <br />
              Protocol (MCP)
            </h2>
          </div>

          <div className="flex flex-col gap-[98px] items-start w-full">
            <p className="text-wwwlangchaincomte-papa-green text-lg md:text-[22px] leading-[35.2px] [font-family:'ABC_Diatype-Regular',Helvetica]">
              MCP is an open protocol that standardizes how applications provide
              context to LLMs. Think of MCP like a USB-C port for AI
              applications. Just as USB-C provides a standardized way to connect
              your device.
            </p>

            <div className="w-full max-w-[436px] border-b border-[#1d3d3c] pb-2 relative">
              <div className="flex justify-between items-center">
                <span className="font-normal text-wwwlangchaincomte-papa-green text-lg md:text-[22px] leading-[35.2px] [font-family:'ABC_Diatype-Regular',Helvetica]">
                  Read the Doc&apos;s Now
                </span>
                <img
                  className="w-[15px] h-3"
                  alt="Component"
                  src="/component-2.svg"
                />
              </div>
            </div>
          </div>
        </div>

        <Card className="w-full md:w-[717px] rounded-[35px] border-black">
          <CardContent className="p-2.5 flex items-center justify-center">
            <div className="relative w-full max-w-[711px] h-[200px]">
              {/* Left section with robot */}
              <div className="absolute w-[415px] h-[200px] top-0 left-0">
                <div className="relative h-[200px]">
                  <div className="w-[377px] top-5 left-[21px] rounded-[188.47px/76px] absolute h-[152px] blur-[55.67px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(98,77,227,1)_0%,rgba(193,31,245,1)_23%,rgba(250,3,255,1)_41%,rgba(250,3,255,1)_51%,rgba(178,7,255,1)_65%,rgba(21,16,255,1)_86%)] opacity-10" />

                  <img
                    className="w-[171px] left-0 absolute h-[200px] top-0"
                    alt="Pulse"
                    src="/pulse-1-5.svg"
                  />

                  <img
                    className="w-[171px] left-0 absolute h-[200px] top-0"
                    alt="Pulse"
                    src="/pulse-2-5.svg"
                  />

                  <div className="absolute w-[345px] h-[108px] top-[46px] left-[39px]">
                    <div className="inline-flex relative left-1.5 items-start gap-2 p-[22px] rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                      <img
                        className="w-16 h-16"
                        alt={mcpImages[0].alt}
                        src={mcpImages[0].src}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Right section with mask group and database */}
              <div className="absolute w-[461px] h-[200px] top-0 left-[250px]">
                <div className="relative h-[200px]">
                  <div className="w-[440px] top-5 left-0 rounded-[220px/76px] absolute h-[152px] blur-[55.67px] [background:conic-gradient(from_180deg_at_50%_50%,rgba(98,77,227,1)_0%,rgba(193,31,245,1)_23%,rgba(250,3,255,1)_41%,rgba(250,3,255,1)_51%,rgba(178,7,255,1)_65%,rgba(21,16,255,1)_86%)] opacity-10" />

                  <img
                    className="w-[180px] left-[254px] absolute h-[200px] top-0"
                    alt="Pulse"
                    src="/pulse-1-1.svg"
                  />

                  <img
                    className="w-[180px] left-[254px] absolute h-[200px] top-0"
                    alt="Pulse"
                    src="/pulse-2-7.svg"
                  />

                  <div className="absolute w-[180px] h-[200px] top-0 left-0">
                    <img
                      className="w-[180px] left-0 absolute h-[200px] top-0"
                      alt="Pulse"
                      src="/pulse-1-3.svg"
                    />

                    <img
                      className="w-[180px] left-0 absolute h-[200px] top-0"
                      alt="Pulse"
                      src="/pulse-2-3.svg"
                    />
                  </div>

                  <div className="flex w-[362px] items-center justify-between absolute top-[46px] left-[46px]">
                    <div className="inline-flex relative flex-[0_0_auto] items-start gap-2 p-[22px] rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                      <img
                        className="w-16 h-16"
                        alt={mcpImages[1].alt}
                        src={mcpImages[1].src}
                      />
                    </div>

                    <div className="flex w-[108px] h-[108px] items-center justify-center gap-2 p-4 relative rounded-3xl overflow-hidden border-[none] shadow-[0px_4px_24px_#624de31f,12px_12px_24px_#f903ff0f,-8px_12px_24px_#140fff14,0px_4px_4px_#0000000a] backdrop-blur-[10px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(10px)_brightness(100%)] [background:radial-gradient(50%_50%_at_50%_50%,rgba(255,255,255,0.3)_60%,rgba(231,228,251,0.3)_100%)]">
                      <img
                        className="w-16 h-16"
                        alt={mcpImages[2].alt}
                        src={mcpImages[2].src}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};
