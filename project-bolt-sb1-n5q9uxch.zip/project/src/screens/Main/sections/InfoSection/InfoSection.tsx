import React from "react";
import { Button } from "../../../../components/ui/button";

export const InfoSection = (): JSX.Element => {
  return (
    <section className="flex flex-col items-center justify-center gap-6 w-full max-w-[720px] mx-auto py-16">
      <div className="flex flex-col items-center w-full">
        <h2 className="text-9xl text-center tracking-[-0.56px] leading-[122px] [font-family:'ABC_Diatype-Regular',Helvetica] font-normal [text-shadow:0px_4px_5.8px_#00000026] bg-[linear-gradient(230deg,rgba(20,241,149,1)_0%,rgba(153,69,255,1)_100%)] [-webkit-background-clip:text] bg-clip-text [-webkit-text-fill-color:transparent] [text-fill-color:transparent]">
          Ready to start your journey
        </h2>
      </div>

      <div className="inline-flex items-center justify-center p-2.5">
        <p className="text-[22px] text-center [font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-[#043e5d] leading-[35.2px]">
          We don&apos;t build tools.
          <br /> We build thinking machines for blockchain.
        </p>
      </div>

      <div className="flex items-center justify-center gap-4 pt-8 w-full">
        <Button className="px-[41px] py-[17px] bg-[#14f195] rounded-[64px] border border-solid border-black [font-family:'ABC_Diatype-Bold',Helvetica] font-bold text-black text-2xl leading-8">
          Start Now
        </Button>

        <Button
          variant="outline"
          className="px-[41px] py-[17px] rounded-[64px] border border-solid border-[#043e5d] [font-family:'ABC_Diatype-Medium',Helvetica] font-medium text-[#043e5d] text-xl leading-8"
        >
          READ DOCS
        </Button>
      </div>
    </section>
  );
};
