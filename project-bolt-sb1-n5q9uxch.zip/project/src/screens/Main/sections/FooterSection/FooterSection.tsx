import React from "react";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";

export const FooterSection = (): JSX.Element => {
  // Footer navigation data
  const footerLinks = {
    products: [{ name: "CogniHash AI", href: "#" }],
    resources: [
      {
        name: "Cogni Docs",
        href: "#",
        fontFamily: "[font-family:'Plus_Jakarta_Sans',Helvetica]",
      },
      { name: "GitHub", href: "#" },
      { name: "Integrations", href: "#" },
      {
        name: "Community",
        href: "#",
        fontFamily: "[font-family:'Plus_Jakarta_Sans',Helvetica]",
      },
    ],
    company: [
      { name: "About", href: "#" },
      { name: "Blog", href: "#" },
      { name: "Twitter", href: "#" },
      { name: "LinkedIn", href: "#" },
      { name: "YouTube", href: "#" },
      { name: "Brandkit", href: "#" },
    ],
  };

  return (
    <footer className="w-full bg-[#9945ff] py-14 relative">
      <div className="container mx-auto px-6 flex flex-wrap">
        {/* Products Column */}
        <div className="w-32 flex flex-col items-start gap-[18px] mr-16">
          <h3 className="[font-family:'ABC_Diatype-Bold',Helvetica] font-bold text-white text-xl leading-[34.6px]">
            Products
          </h3>
          <ul className="w-full">
            {footerLinks.products.map((link, index) => (
              <li key={`product-${index}`} className="py-2">
                <a
                  href={link.href}
                  className="[font-family:'ABC_Diatype-Light',Helvetica] font-light text-white text-xl leading-[30px]"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Resources Column */}
        <div className="w-[115px] flex flex-col items-start gap-4 mr-16">
          <h3 className="[font-family:'ABC_Diatype-Bold',Helvetica] font-bold text-white text-xl leading-[34.6px]">
            Resources
          </h3>
          <ul className="w-full">
            {footerLinks.resources.map((link, index) => (
              <li key={`resource-${index}`} className="py-2 w-full">
                <a
                  href={link.href}
                  className={`${link.fontFamily || "[font-family:'ABC_Diatype-Light',Helvetica]"} font-light text-white text-xl leading-[30px]`}
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Company Column */}
        <div className="w-[97px] flex flex-col items-start gap-[15px] mr-16">
          <h3 className="[font-family:'ABC_Diatype-Bold',Helvetica] font-bold text-white text-xl leading-[34.6px]">
            Company
          </h3>
          <ul className="w-full">
            {footerLinks.company.map((link, index) => (
              <li
                key={`company-${index}`}
                className="py-2 flex items-center justify-center"
              >
                <a
                  href={link.href}
                  className="[font-family:'ABC_Diatype-Light',Helvetica] font-light text-white text-xl leading-[30px]"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Newsletter Section */}
        <div className="flex-1 flex flex-col">
          <h3 className="[font-family:'ABC_Diatype-Light',Helvetica] font-light text-white text-[21.6px] leading-[34.6px] mb-4">
            Sign up for our newsletter to stay up to date
          </h3>

          <div className="flex w-full items-center">
            <div className="flex-1 border-b border-white pb-[24.5px] pt-[22.5px]">
              <Input
                type="email"
                placeholder="Your email..."
                className="border-none bg-transparent [font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-white text-xl placeholder:text-white focus-visible:ring-0 focus-visible:ring-offset-0 p-0"
              />
            </div>
            <Button
              variant="ghost"
              className="min-w-[74px] min-h-[74px] border-b border-white rounded-none p-0 hover:bg-transparent"
            >
              <div className="flex items-center justify-center w-[74px] h-[74px]">
                <img
                  className="w-[19px] h-[19px]"
                  alt="Submit"
                  src="/component-2-2.svg"
                />
              </div>
            </Button>
          </div>
        </div>

        {/* Logo Section */}
        <div className="w-full flex justify-end mt-32">
          <div className="relative">
            <img
              className="w-[310px] h-[310px] object-cover"
              alt="CogniHash Logo"
              src="/logo-white-transbg-3x-1.png"
            />
            <div className="absolute top-[65px] left-[208px] [font-family:'Plus_Jakarta_Sans',Helvetica] font-semibold text-white text-[150px] text-right leading-5">
              CogniHash
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="w-full mt-16 pt-8 border-t border-white flex justify-between items-center">
          <div className="flex items-center gap-3 py-2">
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <span className="[font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-white text-xl leading-[30px]">
              All systems operational
            </span>
          </div>

          <div className="flex gap-8">
            <a
              href="#"
              className="py-2 [font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-white text-xl leading-[30px]"
            >
              Privacy Policy
            </a>
            <a
              href="#"
              className="py-2 [font-family:'ABC_Diatype-Regular',Helvetica] font-normal text-white text-xl leading-[30px]"
            >
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
