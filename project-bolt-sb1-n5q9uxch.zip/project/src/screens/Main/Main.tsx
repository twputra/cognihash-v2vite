import React from "react";
import { FeatureSection } from "./sections/FeatureSection";
import { FooterSection } from "./sections/FooterSection";
import { HeaderSection } from "./sections/HeaderSection";
import { InfoSection } from "./sections/InfoSection";
import { MainContentSection } from "./sections/MainContentSection";
import { PartnerSection } from "./sections/PartnerSection";

export const Main = (): JSX.Element => {
  return (
    <main className="flex flex-col w-full bg-white">
      <HeaderSection />
      <MainContentSection />
      <FeatureSection />
      <PartnerSection />
      <InfoSection />
      <FooterSection />
    </main>
  );
};
